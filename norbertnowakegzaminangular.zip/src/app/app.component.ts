import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { KalkulatorComponent } from './kalkulator/kalkulator.component';
import { KlikniecieComponent } from './klikniecie/klikniecie.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,KalkulatorComponent,KlikniecieComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'sprawdzian';
}
