import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KlikniecieComponent } from './klikniecie.component';

describe('KlikniecieComponent', () => {
  let component: KlikniecieComponent;
  let fixture: ComponentFixture<KlikniecieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [KlikniecieComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(KlikniecieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
