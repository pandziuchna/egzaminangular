import { Component } from '@angular/core';

@Component({
  selector: 'app-klikniecie',
  standalone: true,
  imports: [],
  templateUrl: './klikniecie.component.html',
  styleUrl: './klikniecie.component.css'
})
export class KlikniecieComponent {
}
