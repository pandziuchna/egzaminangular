import { Component } from '@angular/core';
import { KlikniecieComponent } from '../klikniecie/klikniecie.component';

@Component({
  selector: 'app-kalkulator',
  standalone: true,
  imports: [KlikniecieComponent],
  templateUrl: './kalkulator.component.html',
  styleUrl: './kalkulator.component.css'
})
export class KalkulatorComponent {

}
